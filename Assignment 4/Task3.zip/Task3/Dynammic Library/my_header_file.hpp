#ifndef MY_HEADER_FILE_HPP
#define MY_HEADER_FILE_HPP

#include <iostream>

class MyClass {
public:
    void myFunction(int x);
};

#endif // MY_HEADER_FILE_HPP
