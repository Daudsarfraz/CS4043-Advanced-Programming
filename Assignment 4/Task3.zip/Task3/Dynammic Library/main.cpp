#include "my_header_file.hpp"

int main() {
    MyClass obj;
    obj.myFunction(6);
    return 0;
}
