#include "my_header_file.hpp"

void MyClass::myFunction(int x) {
    if (x % 2 == 0) {
        std::cout << "even" << std::endl;
    } else {
        std::cout << "odd" << std::endl;
    }
}
