#include <iostream>
#include <boost/tokenizer.hpp>
#include "my_header_file.hpp"

//#define x 5
int main() {
    MyClass obj;  // Create an instance of MyClass
    obj.myFunction(Val);    // Call the function
    return 0;
}
