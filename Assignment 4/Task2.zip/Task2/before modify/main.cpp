#include <iostream>
#include "my_header_file.hpp"

int main() {
    MyClass obj;
    obj.myFunction(X_Val);  // Using the value of x defined during compilation
    return 0;
}
