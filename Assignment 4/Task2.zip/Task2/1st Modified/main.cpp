#include <iostream>
#include <boost/tokenizer.hpp>
#include "my_header_file.hpp"
int main() {
Myclass obj;
obj.myFunction(6);
return 0;
}