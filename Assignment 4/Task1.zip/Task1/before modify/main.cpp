#include <iostream>
#include <boost/tokenizer.hpp>
// #include "my_header_file.hpp"
// Q#1 .hpp -> .txt
// #include "my_header_file.txt"
// Q#2 change  "" -> < >
// #include <my_header_file.hpp>
// #include <my_header_file.txt>

// Q#3 Include Twice into main file
// #include "my_header_file.hpp"
// #include "my_header_file.hpp"

int main() {
std::cout << "File Inclusions Test" << std::endl;
return 0;
}