#ifdef MY_HEADER_FILE_HPP
#define MY_HEADER_FILE_HPP
class MyClass {
public:
void myFunction();
};
#endif