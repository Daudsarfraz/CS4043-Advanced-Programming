class MyClass {
public:
void myFunction();
};